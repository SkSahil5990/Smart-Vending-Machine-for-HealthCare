from flask import Flask, request, jsonify
from flask import Flask, render_template, request, redirect, url_for
import google.generativeai as genai
from flask_cors import CORS
import requests
import os
import urllib.parse
#from google.generativeai.types import Content, Part


API_KEY = "AIzaSyArgC-0johiWqW-lig9oGxQCx6vnSNCaw4"
# GEMINI_API_KEY = "AIzaSyCz2i6Vs08mSQM6_yUzgeRDDj7gqpDz5bo"  
# GEMINI_API_KEY = "AIzaSyDAQalK2rzCvHBFWeyHbGHZy77bLAj75iA"
GEMINI_API_KEY = "AIzaSyCitUV9NAJ-dbe57cJokVVWaVdcauXF3tQ"
OPENAI_API_KEY = "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"
#OPENAI_API_KEY = "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"


if not GEMINI_API_KEY or not OPENAI_API_KEY:
    raise ValueError("❌ Missing API keys! Set GEMINI_API_KEY and OPENAI_API_KEY in environment variables.")


genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel("gemini-1.5-pro-latest")

app = Flask(__name__)
CORS(app)  # Allow requests from frontend


@app.route('/')
def home():
    return render_template("index.html")

@app.route('/map')
def main():
    return render_template("map.html")
@app.route('/upload')
def upload():
    return render_template("upload.html")


@app.route('/ocr', methods=['POST'])
def extract_text_from_image():
    """Extracts text from an uploaded image using Google Gemini AI."""
    try:
        if 'image' not in request.files:
            return jsonify({"error": "No image file uploaded"}), 400
        
        image_file = request.files['image']
        image_data = image_file.read()

        response = model.generate_content([
            {"mime_type": "image/png", "data": image_data},
            "Extract all readable content including handwritten and printed text from this prescription image."
        ])

        extracted_text = response.text if response.text else "❌ No text extracted."
        return jsonify({"data": extracted_text})

    except Exception as e:
        print("Error during OCR:", str(e))
        return jsonify({"error": "Something went wrong during text extraction."}), 500
# @app.route('/nearbymedicare/<latitude>/<longitude>', methods=['POST'])
# def find_nearby_pharmacies(latitude, longitude):
#     radius = 2000
#     url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json"

#     params = {
#         "location": f"{latitude},{longitude}",
#         "radius": radius,
#         "type": "pharmacy",
#         "key": "AIzaSyArgC-0johiWqW-lig9oGxQCx6vnSNCaw4"
#     }

#     response = requests.get(url, params=params)
#     data = response.json()

#     if "results" not in data:
#         print("No results found or error occurred.")
        

#     print(f"\nNearby Pharmacies within {radius} meters:\n")
#     for place in data["results"]:
#         name = place.get("name", "N/A")
#         address = place.get("vicinity", "Address not available")
#         rating = place.get("rating", "No rating")
#         open_now = place.get("opening_hours", {}).get("open_now", None)
#         open_status = "Open Now" if open_now else "Closed" if open_now == False else "Unknown"


@app.route('/result', methods=['POST'])
def generate_diet_chart():
    try:
        data = request.get_json()
        text = data.get('text', '')
        prompt = f"""Generate a personalized diet chart based on this prescription or report :\n{text}"""

        response = model.generate_content(prompt)
        diet_chart = response.text

        return jsonify({
            "diet_chart": diet_chart,
            "extracted_text": text
        })
        # return render_template("result.html")

    except Exception as e:
        return jsonify({"error": str(e)}), 500


 



if __name__ == '__main__':
    app.run(debug=True,  host='0.0.0.0', port=80)
